export function noop() {
    const fn = function () { };
    return fn;
}
