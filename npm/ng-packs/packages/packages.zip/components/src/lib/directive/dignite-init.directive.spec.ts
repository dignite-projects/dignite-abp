import { DigniteInitDirective } from './dignite-init.directive';

describe('DigniteInitDirective', () => {
  it('should create an instance', () => {
    const directive = new DigniteInitDirective();
    expect(directive).toBeTruthy();
  });
});
