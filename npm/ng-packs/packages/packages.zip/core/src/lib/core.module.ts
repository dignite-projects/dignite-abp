import { NgModule } from '@angular/core';
import { CoreComponent } from './core.component';



@NgModule({
  declarations: [
    CoreComponent
  ],
  imports: [
  ],
  exports: [
    CoreComponent
  ]
})
export class CoreModule { }
