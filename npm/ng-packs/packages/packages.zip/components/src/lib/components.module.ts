import { APP_INITIALIZER, NgModule } from '@angular/core';
import { PageComponent } from './components/page/page.component';
import { CommonModule, NgTemplateOutlet } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbToastModule, NgbCollapseModule, NgbDatepickerModule, NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NzTreeModule } from 'ng-zorro-antd/tree';
import { NzTreeSelectModule } from 'ng-zorro-antd/tree-select';
import { NzInputModule } from 'ng-zorro-antd/input';
import { COMPOENENTS_APPEND_CONTENT } from './tokens';
// import { noop } from 'rxjs';





@NgModule({
  declarations: [
    PageComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgbToastModule,
    NgTemplateOutlet,
    NzTreeModule,
    NzTreeSelectModule,
    NgxDatatableModule,
    NgbCollapseModule,
    NgbDatepickerModule,
    NgbDropdownModule,
    ReactiveFormsModule,
    NzInputModule,
  ],
  exports: [
    PageComponent
  ]
})
export class ComponentsModule { 
  static forRoot(){
    
    return{
      ngModule: ComponentsModule,
      providers: [
        {
        provide: APP_INITIALIZER,
        multi: true,
        deps: [COMPOENENTS_APPEND_CONTENT],
        useFactory: (res)=>{
          console.log(res,'1111111111');
          
        },
      }
    ]
    }
  }
}
