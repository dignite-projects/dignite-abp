/* eslint-disable @angular-eslint/component-selector */
import { Component, ContentChild, Input, TemplateRef } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'dignite-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.scss']
})
export class PageComponent {
  constructor(
    public _location: Location,
  ) { }
  /**
   * 是否允许返回上一页
   * @param 默认false，不允许
   */
  @Input() back: boolean = false

  /**
   * 页面标题
   */
  @Input() title: string = '页面标题'

  /**
   * 容器拓展样式类
   * 可使用class类定义页面滚动 #
   */
  @Input() class: string = ''
  /**
   * 容器拓展样式id
   * 可使用id类定义页面滚动
   */
  @Input() id: string = ''

  /**
   * 页面头部标题右侧
   *  */
  @ContentChild('pageHeader', { static: false }) pageHeader?: TemplateRef<any>;

  /**
   * 页面主体内容添加
   *  */
  @ContentChild('pageBody', { static: false }) pageBody?: TemplateRef<any>;

  /**
   * 返回上一页
   *  */
  goBack() {
    this._location.back();
  }
}
