import { DDatePipe } from './d-date.pipe';

describe('DDatePipe', () => {
  it('create an instance', () => {
    const pipe = new DDatePipe();
    expect(pipe).toBeTruthy();
  });
});
